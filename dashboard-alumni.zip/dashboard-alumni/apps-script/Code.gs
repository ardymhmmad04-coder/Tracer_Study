// Tempel di Google Sheets: Ekstensi > Apps Script. Deploy > Aplikasi web (Akses: Siapa saja).
// Sheet tetap PRIVAT; hanya data aman (tanpa telepon, email, gaji individual, nama atasan) yang dikirim.
const SHEET = 'Form Responses 1';
const pick = (r, ...i) => { for (const x of i) if (r[x] !== '' && r[x] != null) return String(r[x]).trim(); return ''; };
function gajiRange(v) {
  const n = parseInt(String(v).replace(/\D/g, ''), 10); if (!n) return '';
  return n < 1e6 ? '< Rp1 jt' : n < 2e6 ? 'Rp1–2 jt' : n < 3e6 ? 'Rp2–3 jt' : n < 5e6 ? 'Rp3–5 jt' : n < 1e7 ? 'Rp5–10 jt' : '> Rp10 jt';
}
function doGet() {
  const v = SpreadsheetApp.getActive().getSheetByName(SHEET).getDataRange().getValues(); v.shift();
  const data = v.filter(r => r[2]).map(r => ({
    id: Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(r[1] || r[6] || r[2]).toLowerCase())).slice(0, 12),
    ts: r[0] instanceof Date ? r[0].toISOString() : String(r[0]),
    nama: pick(r, 2), jurusan: pick(r, 3), tahun: pick(r, 4), statusRaw: pick(r, 8),
    perusahaan: pick(r, 9, 15), jabatan: pick(r, 10, 16), tahunMasuk: pick(r, 13, 19),
    gaji: gajiRange(pick(r, 14, 20, 27)),
    pt: pick(r, 21, 28), prodi: pick(r, 22, 29), jenjang: pick(r, 23, 30),
    usaha: pick(r, 24), kepemilikan: pick(r, 25), tahunUsaha: pick(r, 26),
    lama: pick(r, 31), kendala: pick(r, 32), aktivitas: pick(r, 33)
  }));
  return ContentService.createTextOutput(JSON.stringify({ data })).setMimeType(ContentService.MimeType.JSON);
}
