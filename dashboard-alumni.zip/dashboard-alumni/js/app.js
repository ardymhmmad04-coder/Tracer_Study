const {createApp}=Vue;
const P={cap:'<path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 2 9 2 12 0v-5"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',chart:'<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',brief:'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>',book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M4 19.5V22h16"/>',shop:'<path d="M3 9l1-5h16l1 5"/><path d="M4 9v11h16V9"/><path d="M9 20v-6h6v6"/>',search:'<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',cal:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',menu:'<path d="M3 6h18M3 12h18M3 18h18"/>',info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>'};
const Icon={props:['n'],template:'<svg class="i" viewBox="0 0 24 24" v-html="p"></svg>',computed:{p(){return P[this.n]}}};
const ChartBox={props:['type','data','options'],template:'<div class="chart"><canvas ref="c"></canvas></div>',
  mounted(){this.ch=new Chart(this.$refs.c,{type:this.type,data:this.clone(),options:this.options})},
  beforeUnmount(){this.ch&&this.ch.destroy()},
  methods:{clone(){return JSON.parse(JSON.stringify(this.data))}},
  watch:{data:{deep:true,handler(){this.ch.data=this.clone();this.ch.update()}}}};

const STATUS=['Bekerja','Bekerja & Kuliah','Melanjutkan Pendidikan','Wirausaha','Belum Bekerja'];
const COLORS={'Bekerja':'#14284b','Bekerja & Kuliah':'#2563eb','Melanjutkan Pendidikan':'#38bdf8','Wirausaha':'#0d9488','Belum Bekerja':'#94a3b8','Lainnya':'#cbd5e1'};
const GAJI=['< Rp1 jt','Rp1–2 jt','Rp2–3 jt','Rp3–5 jt','Rp5–10 jt','> Rp10 jt'];
// Pengelompokan status konsisten berdasarkan kata kunci pada pilihan Google Form
function normStatus(s){const t=(s||'').toLowerCase();
  if(/(bekerja|berkerja)/.test(t)&&/(pendidikan|kuliah)/.test(t))return 'Bekerja & Kuliah';
  if(/(wirausaha|usaha)/.test(t))return 'Wirausaha';
  if(/(belum|mencari|menganggur|tidak)/.test(t))return 'Belum Bekerja';
  if(/(pendidikan|kuliah|melanjutkan)/.test(t))return 'Melanjutkan Pendidikan';
  if(/(bekerja|berkerja)/.test(t))return 'Bekerja';
  return 'Lainnya'}
const count=(arr,order)=>{const m={};arr.forEach(x=>{if(x)m[x]=(m[x]||0)+1});
  const k=order?order.filter(o=>m[o]):Object.keys(m).sort((a,b)=>m[b]-m[a]);return{labels:k,values:k.map(x=>m[x])}};
const ds=(c,col)=>({labels:c.labels,datasets:[{data:c.values,backgroundColor:col,borderRadius:8,borderSkipped:false,maxBarThickness:34}]});
const base={maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{backgroundColor:'#14284b',padding:10,cornerRadius:8}}};
const lbl={id:'lbl',afterDatasetsDraw(ch){if(ch.config.type==='doughnut')return;const c=ch.ctx;c.save();c.fillStyle='#14284b';c.font='600 11px Plus Jakarta Sans';c.textBaseline='middle';
  const h=ch.options.indexAxis==='y';ch.getDatasetMeta(0).data.forEach((b,i)=>{const v=ch.data.datasets[0].data[i];if(h){c.textAlign='left';c.fillText(v,b.x+6,b.y)}else{c.textAlign='center';c.fillText(v,b.x,b.y-9)}});c.restore()}};
Chart.register(lbl);
const sc=(h)=>({x:{grid:{display:h},border:{display:false},ticks:{precision:0}},y:{grid:{display:!h},border:{display:false},ticks:{precision:0}}});

createApp({components:{Icon,ChartBox},
data(){return{cfg:CONFIG,rows:[],loading:true,error:'',view:'dashboard',navOpen:false,q:'',fTahun:'',fJurusan:'',fStatus:'',sel:null,sk:'nama',sd:1,page:1,colors:COLORS,
 menu:[{k:'dashboard',t:'Dashboard',i:'grid'},{k:'alumni',t:'Data Alumni',i:'users'},{k:'statistik',t:'Statistik Tracer Study',i:'chart'},{k:'kerja',t:'Data Pekerjaan',i:'brief'},{k:'studi',t:'Pendidikan Lanjutan',i:'book'},{k:'usaha',t:'Data Wirausaha',i:'shop'}],
 views:{alumni:{t:'Data Alumni',cols:[{k:'nama',t:'Nama Lengkap'},{k:'jurusan',t:'Program Keahlian'},{k:'tahun',t:'Tahun Lulus'},{k:'status',t:'Status Alumni'},{k:'aktivitas',t:'Aktivitas Saat Ini'}]},
  kerja:{t:'Data Pekerjaan',st:['Bekerja','Bekerja & Kuliah'],cols:[{k:'nama',t:'Nama Lengkap'},{k:'perusahaan',t:'Perusahaan / Instansi'},{k:'jabatan',t:'Jabatan'},{k:'tahunMasuk',t:'Tahun Masuk'}]},
  studi:{t:'Pendidikan Lanjutan',st:['Melanjutkan Pendidikan','Bekerja & Kuliah'],cols:[{k:'nama',t:'Nama Lengkap'},{k:'pt',t:'Perguruan Tinggi'},{k:'prodi',t:'Program Studi'},{k:'jenjang',t:'Jenjang'}]},
  usaha:{t:'Data Wirausaha',st:['Wirausaha'],cols:[{k:'nama',t:'Nama Lengkap'},{k:'usaha',t:'Bidang Usaha'},{k:'kepemilikan',t:'Kepemilikan'},{k:'tahunUsaha',t:'Tahun Berdiri'}]}}}},
async mounted(){
  try{const r=await fetch(CONFIG.DATA_URL);if(!r.ok)throw new Error('HTTP '+r.status);const j=await r.json();
    const m=new Map();(j.data||j).forEach(a=>{a.status=normStatus(a.statusRaw);const o=m.get(a.id);if(!o||(a.ts||'')>=(o.ts||''))m.set(a.id,a)}); // satu baris per alumni
    this.rows=[...m.values()]}catch(e){this.error=e.message}
  this.loading=false},
computed:{
 tahunList(){return [...new Set(this.rows.map(r=>r.tahun).filter(Boolean))].sort()},
 jurusanList(){return [...new Set(this.rows.map(r=>r.jurusan).filter(Boolean))].sort()},
 statusList(){return [...new Set(this.rows.map(r=>r.status))]},
 scoped(){return this.rows.filter(r=>(!this.fTahun||String(r.tahun)===String(this.fTahun))&&(!this.fJurusan||r.jurusan===this.fJurusan))},
 periode(){const t=this.tahunList;if(this.fTahun)return 'Lulusan '+this.fTahun;return t.length?'Lulusan '+t[0]+(t.length>1?' – '+t[t.length-1]:''):'Belum ada data'},
 st(){const n=s=>this.scoped.filter(r=>r.status===s).length;return{total:this.scoped.length,kerja:n('Bekerja'),bk:n('Bekerja & Kuliah'),studi:n('Melanjutkan Pendidikan'),usaha:n('Wirausaha'),belum:n('Belum Bekerja')}},
 cards(){const s=this.st;return[{t:'Total Alumni',v:s.total,s:'terdata di tracer study',i:'users',c:'#14284b'},
  {t:'Alumni Bekerja',v:s.kerja+s.bk,s:s.bk?`termasuk ${s.bk} sambil kuliah`:'bekerja penuh waktu',i:'brief',c:'#2563eb'},
  {t:'Melanjutkan Pendidikan',v:s.studi+s.bk,s:s.bk?`termasuk ${s.bk} sambil bekerja`:'kuliah / studi lanjut',i:'book',c:'#0284c7'},
  {t:'Berwirausaha',v:s.usaha,s:'memiliki usaha sendiri',i:'shop',c:'#0d9488'}]},
 rates(){const s=this.st;return[{t:'Bekerja',n:s.kerja+s.bk,c:'#14284b'},{t:'Melanjutkan Pendidikan',n:s.studi+s.bk,c:'#38bdf8'},{t:'Berwirausaha',n:s.usaha,c:'#0d9488'},{t:'Belum Bekerja',n:s.belum,c:'#94a3b8'}]},
 dStatus(){const c=count(this.scoped.map(r=>r.status),[...STATUS,'Lainnya']);return{labels:c.labels,datasets:[{data:c.values,backgroundColor:c.labels.map(l=>COLORS[l]),borderWidth:3,borderColor:'#fff'}]}},
 dTahun(){const y=this.scoped.map(r=>r.tahun?String(r.tahun):'');return ds(count(y,[...new Set(y)].filter(Boolean).sort()),'#2563eb')},
 dJurusan(){return ds(count(this.scoped.map(r=>r.jurusan)),'#14284b')},
 dAktiv(){return ds(count(this.scoped.map(r=>r.aktivitas)),'#38bdf8')},
 gajiN(){return this.scoped.filter(r=>r.gaji).length},
 dGaji(){return ds(count(this.scoped.map(r=>r.gaji),GAJI),'#0284c7')},
 dLama(){return ds(count(this.scoped.map(r=>r.lama)),'#2563eb')},
 dKendala(){return ds(count(this.scoped.flatMap(r=>(r.kendala||'').split(',').map(x=>x.trim()))),'#14284b')},
 oBar(){return{...base,scales:sc(false),layout:{padding:{top:18}}}},
 oHBar(){return{...base,indexAxis:'y',scales:sc(true),layout:{padding:{right:24}}}},
 oDonut(){return{maintainAspectRatio:false,cutout:'66%',plugins:{legend:{position:'bottom',labels:{usePointStyle:true,boxWidth:8,padding:14}},tooltip:{callbacks:{label:c=>` ${c.label}: ${c.raw} (${(c.raw/this.st.total*100).toFixed(1)}%)`}}}}},
 cur(){return this.views[this.view]||this.views.alumni},
 tableRows(){const ql=this.q.trim().toLowerCase(),v=this.cur;return this.scoped.filter(r=>(!v.st||v.st.includes(r.status))&&(!this.fStatus||this.view!=='alumni'||r.status===this.fStatus)&&(!ql||(r.nama||'').toLowerCase().includes(ql)))},
 sorted(){const k=this.sk,d=this.sd;return [...this.tableRows].sort((a,b)=>String(this.val(a,k)).localeCompare(String(this.val(b,k)),'id',{numeric:true})*d)},
 pages(){return Math.max(1,Math.ceil(this.sorted.length/10))},
 paged(){return this.sorted.slice((this.page-1)*10,this.page*10)}},
watch:{view(){this.page=1;this.sk='nama';this.sd=1;this.fStatus=''},q(){this.page=1},fTahun(){this.page=1},fJurusan(){this.page=1},fStatus(){this.page=1}},
methods:{
 go(k){this.view=k;this.navOpen=false;scrollTo(0,0)},
 pct(n){return this.st.total?(n/this.st.total*100).toFixed(1).replace('.',',')+'%':'0%'},
 sortBy(k){this.sd=this.sk===k?-this.sd:1;this.sk=k},
 val(r,k){if(k==='aktivitas')return r.aktivitas||(r.jabatan&&r.perusahaan?`${r.jabatan} di ${r.perusahaan}`:r.pt?`Kuliah di ${r.pt}`:r.usaha?`Usaha ${r.usaha}`:'—');return r[k]||'—'},
 detail(r){const o=[['Program Keahlian',r.jurusan],['Tahun Lulus',r.tahun],['Perusahaan / Instansi',r.perusahaan],['Jabatan',r.jabatan],['Mulai Bekerja',r.tahunMasuk],['Perguruan Tinggi',r.pt],['Program Studi',r.prodi],['Jenjang',r.jenjang],['Bidang Usaha',r.usaha],['Kepemilikan',r.kepemilikan],['Tahun Berdiri',r.tahunUsaha],['Lama Mencari Kerja',r.lama],['Kendala',r.kendala],['Aktivitas',r.aktivitas]];return o.filter(x=>x[1])}}
}).mount('#app');
