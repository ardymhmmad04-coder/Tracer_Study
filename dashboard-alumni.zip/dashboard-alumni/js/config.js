// Ganti DATA_URL dengan URL Web App Apps Script (lihat README) agar data otomatis dari Google Sheets.
window.CONFIG = {
  SCHOOL: 'SMK PGRI 1 Martapura',
  DATA_URL: './data/alumni.json'
};
